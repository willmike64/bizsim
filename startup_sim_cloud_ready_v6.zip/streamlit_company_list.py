def show_company_selection():
    import streamlit as st
    st.write('📦 Company Selection UI')