def render_decision_ui():
    import streamlit as st
    st.write('🧠 CEO Decision Panel')