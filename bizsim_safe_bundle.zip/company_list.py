# company_list.py (stub)
def render():
    pass
