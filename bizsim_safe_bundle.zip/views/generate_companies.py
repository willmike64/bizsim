# generate_companies.py stub
def generate_startups():
    return []
