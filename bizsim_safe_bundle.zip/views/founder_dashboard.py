# founder_dashboard.py stub
def render_investor_ui():
    pass
