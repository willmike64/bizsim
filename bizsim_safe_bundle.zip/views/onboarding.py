# onboarding.py stub
def render_onboarding(navigate):
    pass
