# lobby.py stub
def render_role_picker(navigate):
    pass
def render_lobby(navigate):
    pass
