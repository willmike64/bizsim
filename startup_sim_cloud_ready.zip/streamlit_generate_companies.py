def generate_ui():
    import streamlit as st
    st.write('🏗️ Startup Generator')