# Startup Simulation App

This is a Streamlit-based business simulation application.

## How to Deploy on Streamlit Cloud

1. Upload this repository to GitHub.
2. Go to [https://streamlit.io/cloud](https://streamlit.io/cloud).
3. Connect your GitHub account and select this repo.
4. Choose `app.py` as the main file.
5. Click **Deploy**!

## Requirements

- Python 3.8+
- Streamlit (auto-installed via `requirements.txt`)
